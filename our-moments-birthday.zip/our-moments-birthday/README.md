# A Little Universe — Birthday Surprise

A mobile-friendly single-page birthday experience with animated scenes, a photo gallery, interactive balloons, three customizable gifts, a personal letter, and a shareable URL.

## Preview locally

1. Extract the ZIP.
2. Keep `index.html` and `hum-mar-jayenge.mp3` in the same folder.
3. Open `index.html` in your browser.
4. Local preview is only for testing. A `file://` URL cannot be sent to another person; publish the site first to create a working share link.

## Publish free with GitHub Pages

1. Create a public repository on GitHub.
2. Upload **both** `index.html` and `hum-mar-jayenge.mp3` into the repository root (same folder).
3. Open repository **Settings → Pages**.
4. Under build and deployment, choose **Deploy from a branch**, select `main` and `/(root)`, then save.
5. Wait for GitHub Pages to publish the site. Open its public `https://USERNAME.github.io/REPOSITORY/` URL.
6. Customize your gift on that public page and choose **Create my shareable link**. Send the resulting `https://` URL to the recipient.

## Music behavior

Browsers generally block sound from starting automatically before a user gesture. When someone opens a shareable gift URL, they will see an opening screen with **Open my surprise**. Tapping it starts `hum-mar-jayenge.mp3` and opens the birthday experience. The floating music button lets them pause/resume it. The MP3 must be uploaded beside `index.html` on the same host.

If audio still does not play, check that `hum-mar-jayenge.mp3` is uploaded with the exact filename and is in the same directory as `index.html`.

## Share-link notes

The personalized gift data is stored in the URL fragment. The website must be hosted on a public HTTPS URL for links to work on other devices. Uploaded photos and gift-song data increase the URL size; use small images and keep custom gift songs very short. A URL-encoded gift link is not private storage and cannot be revoked after it is shared.
